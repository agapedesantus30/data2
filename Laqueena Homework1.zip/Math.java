/**
 * Class: Math
 * 
 * @author LaQueena Andem
 * @version 1.0 Course : ITEC 3150 Spring 2019 Written: January 29, 2019
 * 
 * 
 *          This class describes a subclass Math
 * 
 *          Purpose: This class is intended to serve as a sub class of parent
 *          class Courses
 *
 */
public class Math extends Courses {
	private String type;
	private String section;

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Math [CRN=" + cRN + ", Name=" + Name + ", Category=" + Category + ", type=" + type + ", section="
				+ section + "]";
	}

	/**
	 * @param cRN
	 * @param name
	 * @param category
	 * @param type
	 * @param section
	 */
	public Math(int cRN, String name, String category, String type, String section) {
		super(cRN, name, category);
		this.type = type;
		this.section = section;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @return the section
	 */
	public String getSection() {
		return section;
	}
}
