import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Class: CourseList
 * 
 * @author LaQueena Andem
 * @version 1.0 Course : ITEC 3150 Spring 2019 Written: January 29, 2019
 * 
 * 
 *          This class describes CourseList used to contain the Courses item
 *          CourseList. It also contains the main method which starts the
 *          program.
 * 
 *          Purpose: Methods and attributes needed to create a CourseList of
 *          Courses class. Print them, read them from a file, search for a
 *          particular CRN and add a new item.
 *
 */
public class CourseList {

	// actual CourseList data
	private ArrayList<Courses> CourseList = new ArrayList<Courses>();

	/**
	 * Method: printCoursesList()
	 * 
	 * This method prints the Course contained in the CourseList Array list. It
	 * relies on the toString method of the various Courses to print the items in a
	 * user friendly format.
	 * 
	 * 
	 */
	public void printCoursesList() {
		for (int i = 0; i < CourseList.size(); i++) {
			Courses temp = CourseList.get(i);
			System.out.println(temp);
		}
	}

	/**
	 * Method:searchByname()
	 * 
	 * This method looks at each item in the CourseList array list and if its CRN
	 * attribute matches the input parameter CRN, that item is returned to the
	 * caller. It returns null if item is not found.
	 * 
	 * 
	 */
	public Courses searchByName(String name) {
		Courses item = null;
		for (Courses temp : CourseList) {
			if (temp.getName().equalsIgnoreCase(name)) {
				item = temp;
			}
		}
		return item;
	}

	/**
	 * @return the CourseList
	 */
	public ArrayList<Courses> getCourseList() {
		return CourseList;
	}

	/**
	 * Method:addItem()
	 * 
	 * This method adds the parameter @param md to the CourseList array list
	 * 
	 * @param md
	 * 
	 */
	public void addItem(Courses cs) {
		CourseList.add(cs);
	}

	/**
	 * Method:removeItem()
	 * 
	 * This method removes the item with name from the array list
	 * 
	 * @param md
	 * 
	 */
	public void removeItem(String name) {
		Courses cc = this.searchByName(name);
		if (cc != null) {
			CourseList.remove(cc);
		}
	}

	/**
	 * 
	 * Method:main()
	 * 
	 * This method is the starting point of the program. It contains the initial
	 * reading of items from the text file Courses.txt and a menu for allowing user
	 * to choose various tasks.
	 * 
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		// create CourseList by reading in from text file named Courses.txt
		CourseList myCourseList = new CourseList();

		// open text file
		File courseFile = new File("Courses.txt");
		// open a Scanner to read data from File
		Scanner courseReader = null;
		try {
			courseReader = new Scanner(courseFile);
		} catch (FileNotFoundException e) {
			System.out.println("No Courses found in the CourseList - CourseList is empty");
		}

		// reads one Course at a time
		while (courseReader != null && courseReader.hasNext()) {
			String cRNString = courseReader.nextLine();
			int cRN = Integer.parseInt(cRNString);
			String name = courseReader.nextLine();
			String category = courseReader.nextLine();

			if (category.equalsIgnoreCase("English")) {
				String section = courseReader.nextLine();
				String type = courseReader.nextLine();
				English en = new English(cRN, name, category, section, type);
				myCourseList.addItem(en);
			} else if (category.equalsIgnoreCase("History")) {
				String section = courseReader.nextLine();
				String eligibility = courseReader.nextLine();
				History hi = new History(cRN, name, category, section, eligibility);
				myCourseList.addItem(hi);
			} else if (category.equalsIgnoreCase("Math")) {
				String level = courseReader.nextLine();
				String type = courseReader.nextLine();
				Math mt = new Math(cRN, name, category, level, type);
				myCourseList.addItem(mt);
			} else {
				System.out.println("Unknown Course " + category);
			}
		}

		Scanner scn = new Scanner(System.in);

		System.out.println("Welcome to the Course Menu");
		boolean done = false;
		while (!done) {
			System.out.println("");
			System.out.println("Please Follow The Instructions :");
			System.out.println("  Press 1 to View The List Of Courses");
			System.out.println("  Press 2 to Search For A Particular Course");
			System.out.println("  Press 3 to Delete a Course");
			System.out.println("  Press 4 to Exit");
			System.out.println("");
			String str = scn.nextLine();
			int userInput = Integer.parseInt(str);
			if (userInput == 1) {
				myCourseList.printCoursesList();
			} else if (userInput == 2) {
				System.out.println("Please enter a Course Name: Ex Eng-3000");
				String id = scn.nextLine();
				Courses item = myCourseList.searchByName(id);
				if (item != null) {
					System.out.println(item);
				} else {
					System.out.println("Sorry- Course not found");
				}
			} else if (userInput == 3) {
				System.out.println("Please enter the name of course");
				String id2 = scn.nextLine();
				myCourseList.removeItem(id2);
			} else {
				done = true;
				// write out contents of CourseList back to original file
				PrintWriter out = null;
				// open file for writing
				try {
					out = new PrintWriter(new File("Courses.txt"));
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				// write contents of each CourseList item to file
				for (Courses cus : myCourseList.getCourseList()) {
					// first write the attributes common to all
					out.println(cus.getCategory());
					out.println(cus.getName());
					out.println(cus.getCRN());

					if (cus.getCategory().equalsIgnoreCase("English")) {
						// cast to appropriate subclass
						English e = (English) cus;
						// write attributes specific to English
						out.println(e.getLevel());
						out.println(e.getType());
					} else if (cus.getCategory().equalsIgnoreCase("History")) {
						// cast to appropriate subclass
						History h = (History) cus;
						// write attributes specific to History
						out.println(h.getEligibility());
						out.println(h.getSection());
					} else if (cus.getCategory().equalsIgnoreCase("Math")) {
						Math m = (Math) cus;
						out.println(m.getType());
						out.println(m.getSection());
					} else {
						System.out.println("Unknown Course " + cus.getCategory());
					}
				}
				out.close();
			}

		}

	}
}