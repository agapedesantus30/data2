/**
 * Class: Courses
 * 
 * @author LaQueena Andem
 * @version 1.0 Course : ITEC 3150 Spring 2019 Written: January 29, 2019
 * 
 * 
 *          This class describes a superclass Courses
 * 
 *          Purpose: This class is intended to serve as a parent class for all
 *          types of Courses
 *
 */
public class Courses {
	protected int cRN;
	protected String Name;
	protected String Category;

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Courses [CRN=" + cRN + ", Name=" + Name + ", Category=" + Category + "]";
	}

	/**
	 * @param cRN
	 * @param name
	 * @param category
	 */
	public Courses(int cRN, String name, String category) {
		super();
		this.cRN = cRN;
		this.Name = name;
		this.Category = category;
	}

	/**
	 * @return the cRN
	 */
	public int getCRN() {
		return cRN;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return Name;
	}

	/**
	 * @return the category
	 */
	public String getCategory() {
		return Category;
	}
}