/**
 * Class: English
 * 
 * @author LaQueena Andem
 * @version 1.0 Course : ITEC 3150 Spring 2019 Written: January 29, 2019
 * 
 * 
 *          This class describes a subclass English
 * 
 *          Purpose: This class is intended to serve as a sub class of parent
 *          class Courses
 *
 */
public class English extends Courses {
	private String level;
	private String type;

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "English [CRN=" + cRN + ", Name=" + Name + ", Category=" + Category + ",level=" + level + ", type="
				+ type + "]";
	}

	/**
	 * @param cRN
	 * @param name
	 * @param category
	 * @param level
	 * @param type
	 */
	public English(int cRN, String name, String category, String level, String type) {
		super(cRN, name, category);
		this.level = level;
		this.type = type;
	}

	/**
	 * @return the level
	 */
	public String getLevel() {
		return level;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

}
