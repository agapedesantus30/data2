/**
 * Class: History
 * 
 * @author LaQueena Andem
 * @version 1.0 Course : ITEC 3150 Spring 2019 Written: February 28, 2019
 * 
 * 
 *          This class describes a subclass History
 * 
 *          Purpose: This class is intended to serve as a sub class of parent
 *          class Courses
 *
 */
public class History extends Courses {
	private String eligibility;
	private String section;

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "History [CRN=" + cRN + ", Name=" + Name + ", Category=" + Category + ",eligibility=" + eligibility
				+ ", section=" + section + "]";
	}

	/**
	 * @param cRN
	 * @param name
	 * @param category
	 * @param eligibility
	 * @param section
	 */
	public History(int cRN, String name, String category, String eligibility, String section) {
		super(cRN, name, category);
		this.eligibility = eligibility;
		this.section = section;
	}

	/**
	 * @return the eligibility
	 */
	public String getEligibility() {
		return eligibility;
	}

	/**
	 * @return the section
	 */
	public String getSection() {
		return section;
	}
}