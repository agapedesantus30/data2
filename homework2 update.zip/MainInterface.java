import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * 
 * Main GUI class - contains ListView and launches additional Stages as needed
 * 
 * @author LaQueena Andem
 *
 */
public class MainInterface extends Application {
	private CourseList myLibrary = new CourseList();

	/*
	 * (non-Javadoc)
	 * 
	 * @see javafx.application.Application#start(javafx.stage.Stage)
	 */
	@Override
	public void start(Stage primaryStage) throws Exception {
		// read in file and create library
		myLibrary.readBinaryFile();

		// display list of library items
		VBox mainPane = new VBox();
		Label mainLabel = new Label("Course Items");

		mainPane.getChildren().add(mainLabel);
		ListView<Courses> list = new ListView<Courses>();
		ObservableList<Courses> items = FXCollections.observableArrayList(myLibrary.getTheList());
		list.setItems(items);

		mainPane.getChildren().add(list);

		// make list selectable and popup info on selected item in a separate
		// stage
		list.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Courses>() {

			public void changed(ObservableValue<? extends Courses> observable, Courses oldValue, Courses newValue) {
				// pop up detail stage of selected media object
				Stage newStage = null;
				if (newValue.getCategory().equals("English")) {
					newStage = createEnglishStage(newValue);
				} else if (newValue.getCategory().equals("History")) {
					newStage = createHistoryStage(newValue);
				} else {
					newStage = createVideoStage(newValue);
				}

				newStage.show();
			}
		});

		// Create a scene and place it in the stage
		Scene scene = new Scene(mainPane, 500, 200);
		primaryStage.setTitle("Course Library"); // Set the stage title
		primaryStage.setScene(scene); // Place the scene in the stage
		primaryStage.show(); // Display the stage

	}

	/*
	 * Method to create new Stage for a Book Media item
	 * 
	 * @param Media
	 * 
	 * @return Stage
	 */
	private Stage createEnglishStage(Courses cu) {
		Stage s = new Stage();
		GridPane pane = new GridPane();
		pane.setAlignment(Pos.CENTER);
		pane.setPadding(new Insets(11.5, 12.5, 13.5, 14.5));
		pane.setHgap(5.5);
		pane.setVgap(5.5);
		English eng = (English) cu;
		// Place nodes in the pane
		pane.add(new Label("CRN:"), 0, 1);
		pane.add(new Label("" + eng.getCRN()), 1, 1);
		pane.add(new Label("Name:"), 0, 0);
		pane.add(new Label(eng.getName()), 1, 0);
		pane.add(new Label("Category:"), 0, 2);
		pane.add(new Label(eng.getCategory()), 1, 2);
		pane.add(new Label("Level"), 0, 3);
		pane.add(new Label(eng.getLevel()), 1, 3);
		pane.add(new Label("Type"), 0, 4);
		pane.add(new Label(eng.getType()), 1, 4);

		// Create a scene and place it in the stage
		Scene scene = new Scene(pane);
		s.setScene(scene);
		s.setTitle("English");
		return s;
	}

	/*
	 * Method to create new Stage for a Music Media item
	 * 
	 * @param Media
	 * 
	 * @return Stage
	 */
	private Stage createHistoryStage(Courses cu) {

		Stage s = new Stage();
		GridPane pane = new GridPane();
		pane.setAlignment(Pos.CENTER);
		pane.setPadding(new Insets(11.5, 12.5, 13.5, 14.5));
		pane.setHgap(5.5);
		pane.setVgap(5.5);
		History his = (History) cu;
		// Place nodes in the pane
		pane.add(new Label("CRN:"), 0, 1);
		pane.add(new Label("" + his.getCRN()), 1, 1);
		pane.add(new Label("Name:"), 0, 0);
		pane.add(new Label(his.getName()), 1, 0);
		pane.add(new Label("Category:"), 0, 2);
		pane.add(new Label(his.getCategory()), 1, 2);
		pane.add(new Label("Eligibility:"), 0, 2);
		pane.add(new Label(his.getEligibility()), 1, 2);
		pane.add(new Label("Section"), 0, 3);
		pane.add(new Label(his.getSection()), 1, 3);

		// Create a scene and place it in the stage
		Scene scene = new Scene(pane);
		s.setScene(scene);
		s.setTitle("History");
		return s;
	}

	/*
	 * Method to create new Stage for a Video Media item
	 * 
	 * @param Media
	 * 
	 * @return Stage
	 */
	private Stage createVideoStage(Courses cu) {
		Stage s = new Stage();
		GridPane pane = new GridPane();
		pane.setAlignment(Pos.CENTER);
		pane.setPadding(new Insets(11.5, 12.5, 13.5, 14.5));
		pane.setHgap(5.5);
		pane.setVgap(5.5);
		Math math = (Math) cu;
		// Place nodes in the pane
		pane.add(new Label("CRN:"), 0, 1);
		pane.add(new Label("" + math.getCRN()), 1, 1);
		pane.add(new Label("Name:"), 0, 0);
		pane.add(new Label(math.getName()), 1, 0);
		pane.add(new Label("Category:"), 0, 2);
		pane.add(new Label(math.getCategory()), 1, 2);
		pane.add(new Label("Type"), 0, 4);
		pane.add(new Label(math.getType()), 1, 4);
		pane.add(new Label("section"), 0, 5);
		pane.add(new Label(math.getSection()), 1, 5);

		// Create a scene and place it in the stage
		Scene scene = new Scene(pane);
		s.setScene(scene);
		s.setTitle("Math");
		return s;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		launch(args);
	}
}