import java.io.EOFException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Class: CourseList
 * 
 * @author LaQueena Andem
 * @version 1.0 Course : ITEC 3150 Spring 2019 Written: February 28, 2019
 * 
 * 
 *          This class describes CourseList used to contain the Courses item
 *          CourseList.
 * 
 *          Purpose: Methods and attributes needed to create a CourseList of
 *          Courses class. Print them, read them from a file, search for a
 *          particular CRN and add a new item.
 *
 */
public class CourseList {

	// actual CourseList data
	private ArrayList<Courses> courseItems = new ArrayList<Courses>();

	public ArrayList<Courses> getTheList() {
		return courseItems;
	}

	/**
	 * Method:printCourseItems()
	 * 
	 * This method prints the Course items contained in the CourseItems Array list.
	 * It relies on the toString method of the various Course types to print the
	 * items in a user friendly format.
	 * 
	 * 
	 */
	public void printCourseItems() {
		for (int i = 0; i < courseItems.size(); i++) {
			Courses courses = courseItems.get(i);
			System.out.println(courses);
		}

	}

	/**
	 * Method:searchById()
	 * 
	 * This method looks at each item in the CourseItems array list and if its
	 * idNumber attribute matches the input parameter id, that item is returned to
	 * the caller. It returns null if item is not found.
	 * 
	 * @param id
	 * 
	 * @return Courses
	 * 
	 */
	public Courses searchById(int id) {
		Courses item = null;
		for (Courses temp : courseItems) {
			if (temp.getCRN() == id) {
				item = temp;
			}

		}
		return item;
	}

	/**
	 * Method:addItem()
	 * 
	 * This method adds the parameter m to the CourseItems array list
	 * 
	 * @param m
	 * 
	 */
	public void addItem(Courses m) {
		courseItems.add(m);
	}

	/**
	 * Method:deleteItem()
	 * 
	 * This method deletes the parameter m from the courseItems array list
	 * 
	 * @param m
	 * @return
	 * 
	 */
	public void deleteItem(int m) {
		Courses item = searchById(m);
		if (item != null) {
			courseItems.remove(item);
		} else {
			System.out.println("Can not delete- item number does not exist");
		}
	}

	/**
	 * readBinaryFile()
	 * 
	 * This method populates the courseItems array list from a binary files
	 */
	public void readBinaryFile() {
//		try { // Create an input stream for file object.dat
//			ObjectInputStream input = new ObjectInputStream(
//					new FileInputStream("C:/Users/agape/Desktop/Courses.dat"));
//			while (true) {
//				Courses cu = (Courses) input.readObject();
//				addItem(cu);
//			}
//		} catch (EOFException ex) {
//			// do nothing reached the end of the file
//		} catch (IOException i) {
//			System.out.println("Unable to read from file");
//			i.printStackTrace();
//		} catch (ClassNotFoundException c) {
//			System.out.println("Object read is not a java.util.Date instance");
//		}

		File courseFile = new File("C:/Users/agape/Desktop/Courses.dat");
		Scanner courseReader = null;
		try {
			courseReader = new Scanner(courseFile);
		} catch (FileNotFoundException e) {
			System.out.println("No Courses found in the CourseList - CourseList is empty");
		}

	}

	/**
	 * Method:readTextFile()
	 * 
	 * This method populates the courseItems array list from a text file
	 * 
	 * 
	 * 
	 */
	public void readTextFile() {
		// open text file
		File courseFile = new File("C:/Users/agape/Desktop/courses.txt");
		// open a Scanner to read data from File
		Scanner courseReader = null;
		try {
			courseReader = new Scanner(courseFile);
		} catch (FileNotFoundException e) {
			System.out.println("No library media found- library is empty");
		}

		// read one course at a time
		while (courseReader != null && courseReader.hasNext()) {

			String cRNString = courseReader.nextLine();
			int cRN = Integer.parseInt(cRNString);
			String name = courseReader.nextLine();
			String category = courseReader.nextLine();

			if (category.equalsIgnoreCase("English")) {
				String level = courseReader.nextLine();
				String type = courseReader.nextLine();
				English en = new English(cRN, name, category, level, type);
				addItem(en);

			} else if (category.equalsIgnoreCase("History")) {
				String eligibility = courseReader.nextLine();
				String section = courseReader.nextLine();
				History hi = new History(cRN, name, category, eligibility, section);
				addItem(hi);

			} else if (category.equalsIgnoreCase("Math")) {
				String type = courseReader.nextLine();
				String section = courseReader.nextLine();
				Math mth = new Math(cRN, name, category, type, section);
				addItem(mth);
			} else {
				System.out.println("Unknown course type " + category);
			}

		}
	}

	/**
	 * Method:writeTextFile()
	 * 
	 * This method populates the text file with content of courseItems
	 * 
	 * 
	 * 
	 */
	public void writeTextFile() {
		// open text file
		File courseFile = new File("C:/Users/agape/Desktop/courses.txt");
		// open a Scanner to read data from File
		PrintWriter courseWritter = null;
		try {
			courseWritter = new PrintWriter(courseFile);
		} catch (FileNotFoundException e) {

			System.out.println("unable to open courses.txt for writing");
		}

		if (courseWritter != null) {
			for (Courses item : courseItems) {
				// write course item one at a time
				courseWritter.println("" + item.getCRN());
				courseWritter.println(item.getName());
				courseWritter.println(item.getCategory());

				if (item.getCategory().equalsIgnoreCase("English")) {
					// cast item to English to get English specific attributes
					English temp = (English) item;
					courseWritter.println(temp.getLevel());
					courseWritter.println(temp.getType());

				} else if (item.getCategory().equalsIgnoreCase("History")) {
					// cast item to History to get History specific attributes
					History temp = (History) item;
					courseWritter.println(temp.getEligibility());
					courseWritter.println(temp.getSection());
				} else if (item.getCategory().equalsIgnoreCase("Math")) {
					// cast Math to Book to get Math specific attributes
					Math temp = (Math) item;
					courseWritter.println(temp.getType());
					courseWritter.println(temp.getSection());
				} else {
					System.out.println("Unknown course type " + item.getCategory());
				}
			}
		}
		courseWritter.close();

	}
}
