import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class DisplayHistogram extends Application {

	private static int freq[] = new int[10];
	private TextField EnterDigitLessThan10 = new TextField();
	private Button ShowHistogram = new Button("Display Histogram");

	public void start(Stage primaryStage) {
		// Create UI
		GridPane gridPane = new GridPane();
		gridPane.setHgap(5);
		gridPane.setVgap(5);
		gridPane.add(new Label("Enter Digit Less Than 10 :"), 0, 0);
		gridPane.add(EnterDigitLessThan10, 1, 0);
		gridPane.add(ShowHistogram, 1, 5);

		// Set properties for UI
		gridPane.setAlignment(Pos.CENTER);
		EnterDigitLessThan10.setAlignment(Pos.BOTTOM_RIGHT);
		GridPane.setHalignment(ShowHistogram, HPos.RIGHT);

		// Process events
		ShowHistogram.setOnAction(e -> calculateHistogram());

		// Create a scene and place it in the stage
		Scene scene = new Scene(gridPane, 700, 300);
		primaryStage.setTitle("Frequency Of Histogram"); // Set title
		primaryStage.setScene(scene); // Place the scene in the stage
		primaryStage.show(); // Display the stage
	}

	private void calculateHistogram() {
		// Get values from text fields
		int num = Integer.parseInt(EnterDigitLessThan10.getText());
		int number = Integer.valueOf(num);
		for (int i = 0; i < 10; i++) {
			freq[i] = 0;
		}
		int digit;
		while (number > 0) {
			digit = number % 10;
			freq[digit]++;
			number = number / 10;
		}

		// Display Histogram calculated
		System.out.println("Digit \t" + "Frequency");
		for (int i = 0; i < 10; i++) {
			if (freq[i] != 0) {
				System.out.println(i + "\t" + freq[i]);
			}
		}

		Stage stage = new Stage();
		stage.setTitle("Histogram");
		HBox box = new HBox(20);
		box.setAlignment(Pos.BOTTOM_CENTER);
		box.setPadding(new Insets(25, 25, 25, 25));
		Rectangle[] rects = new Rectangle[10];
		for (int i = 0; i < freq.length; i++) {
			rects[i] = new Rectangle();
			rects[i].setHeight((freq[i] / 10.0) * 250);
			rects[i].setWidth(25);
		}
		box.getChildren().addAll(rects);
		stage.setScene(new Scene(box, 500, 300));
		stage.show();
	}

	/**
	 * The main method is only needed for the IDE with limited JavaFX support. Not
	 * needed for running from the command line.
	 */
	public static void main(String[] args) {
		launch(args);
	}
}
